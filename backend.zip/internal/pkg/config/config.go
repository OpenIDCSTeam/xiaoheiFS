package config

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"os"
	"strings"

	"gopkg.in/yaml.v3"
)

const (
	localConfigYAML = "app.config.yaml"
	localConfigYML  = "app.config.yml"
	localConfigJSON = "app.config.json"
)

type Config struct {
	Addr              string
	DBType            string
	DBPath            string
	DBDSN             string
	AdminUser         string
	AdminPass         string
	JWTSecret         string
	PluginMasterKey   string
	PluginOfficialKeys []string
	APIBase           string
	SiteName          string
	SiteURL           string
	AutomationBaseURL string
	AutomationAPIKey  string
}

type fileConfig struct {
	Addr    string `json:"addr" yaml:"addr"`
	APIBase string `json:"api_base_url" yaml:"api_base_url"`

	JWTSecret string `json:"jwt_secret" yaml:"jwt_secret"`
	PluginMasterKey string   `json:"plugin_master_key" yaml:"plugin_master_key"`
	PluginOfficialKeys []string `json:"plugin_official_ed25519_pubkeys" yaml:"plugin_official_ed25519_pubkeys"`

	DB struct {
		Type string `json:"type" yaml:"type"`
		Path string `json:"path" yaml:"path"`
		DSN  string `json:"dsn" yaml:"dsn"`
	} `json:"db" yaml:"db"`
}

func Load() Config {
	cfg := Config{
		Addr:              ":8080",
		DBType:            "sqlite",
		DBPath:            "./data/app.db",
		DBDSN:             "",
		AdminUser:         "admin",
		AdminPass:         "admin123",
		JWTSecret:         "",
		PluginMasterKey:   "",
		PluginOfficialKeys: nil,
		APIBase:           "http://localhost:8080",
		SiteName:          "",
		SiteURL:           "",
		AutomationBaseURL: "",
		AutomationAPIKey:  "",
	}

	applyFileConfig(&cfg, readLocalConfig())

	if strings.TrimSpace(cfg.JWTSecret) == "" {
		cfg.JWTSecret = generateSecret()
		_ = persistJWTSecret(cfg.JWTSecret)
	}
	if strings.TrimSpace(cfg.PluginMasterKey) == "" {
		cfg.PluginMasterKey = generateSecret()
		_ = persistPluginMasterKey(cfg.PluginMasterKey)
	}

	return cfg
}

func readLocalConfig() *fileConfig {
	candidates := []string{localConfigYAML, localConfigYML, localConfigJSON}

	for _, p := range candidates {
		if strings.TrimSpace(p) == "" {
			continue
		}
		b, err := os.ReadFile(p)
		if err != nil {
			continue
		}

		var fc fileConfig
		switch {
		case strings.HasSuffix(strings.ToLower(p), ".yaml") || strings.HasSuffix(strings.ToLower(p), ".yml"):
			if yaml.Unmarshal(b, &fc) == nil {
				return &fc
			}
		case strings.HasSuffix(strings.ToLower(p), ".json"):
			// Support both new nested JSON and the legacy flat JSON produced by older installers.
			if json.Unmarshal(b, &fc) == nil {
				return &fc
			}
			var legacy struct {
				DBType string `json:"db_type"`
				DBPath string `json:"db_path"`
				DBDSN  string `json:"db_dsn"`
			}
			if json.Unmarshal(b, &legacy) == nil {
				fc.DB.Type = legacy.DBType
				fc.DB.Path = legacy.DBPath
				fc.DB.DSN = legacy.DBDSN
				return &fc
			}
		default:
			// If extension is unknown, try YAML then JSON.
			if yaml.Unmarshal(b, &fc) == nil {
				return &fc
			}
			if json.Unmarshal(b, &fc) == nil {
				return &fc
			}
		}
	}
	return nil
}

func applyFileConfig(cfg *Config, fc *fileConfig) {
	if cfg == nil || fc == nil {
		return
	}
	if strings.TrimSpace(fc.Addr) != "" {
		cfg.Addr = strings.TrimSpace(fc.Addr)
	}
	if strings.TrimSpace(fc.APIBase) != "" {
		cfg.APIBase = strings.TrimSpace(fc.APIBase)
	}
	if strings.TrimSpace(fc.JWTSecret) != "" {
		cfg.JWTSecret = strings.TrimSpace(fc.JWTSecret)
	}
	if strings.TrimSpace(fc.PluginMasterKey) != "" {
		cfg.PluginMasterKey = strings.TrimSpace(fc.PluginMasterKey)
	}
	if len(fc.PluginOfficialKeys) > 0 {
		cfg.PluginOfficialKeys = fc.PluginOfficialKeys
	}
	if strings.TrimSpace(fc.DB.Type) != "" {
		cfg.DBType = strings.TrimSpace(fc.DB.Type)
	}
	if strings.TrimSpace(fc.DB.Path) != "" {
		cfg.DBPath = strings.TrimSpace(fc.DB.Path)
	}
	if strings.TrimSpace(fc.DB.DSN) != "" {
		cfg.DBDSN = strings.TrimSpace(fc.DB.DSN)
	}
}

func generateSecret() string {
	b := make([]byte, 32)
	_, _ = rand.Read(b)
	return base64.RawURLEncoding.EncodeToString(b)
}

func persistJWTSecret(secret string) error {
	path := localConfigYAML
	switch {
	case fileExists(localConfigYAML):
		path = localConfigYAML
	case fileExists(localConfigYML):
		path = localConfigYML
	case fileExists(localConfigJSON):
		path = localConfigJSON
	default:
		path = localConfigYAML
	}

	if strings.HasSuffix(strings.ToLower(path), ".json") {
		out := map[string]any{}
		if existing, err := os.ReadFile(path); err == nil {
			_ = json.Unmarshal(existing, &out)
		}
		out["jwt_secret"] = secret
		b, err := json.MarshalIndent(out, "", "  ")
		if err != nil {
			return err
		}
		return os.WriteFile(path, b, 0o600)
	}

	out := map[string]any{}
	if existing, err := os.ReadFile(path); err == nil {
		_ = yaml.Unmarshal(existing, &out)
	}
	out["jwt_secret"] = secret
	b, err := yaml.Marshal(&out)
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0o600)
}

func persistPluginMasterKey(key string) error {
	path := localConfigYAML
	switch {
	case fileExists(localConfigYAML):
		path = localConfigYAML
	case fileExists(localConfigYML):
		path = localConfigYML
	case fileExists(localConfigJSON):
		path = localConfigJSON
	default:
		path = localConfigYAML
	}

	if strings.HasSuffix(strings.ToLower(path), ".json") {
		out := map[string]any{}
		if existing, err := os.ReadFile(path); err == nil {
			_ = json.Unmarshal(existing, &out)
		}
		out["plugin_master_key"] = key
		b, err := json.MarshalIndent(out, "", "  ")
		if err != nil {
			return err
		}
		return os.WriteFile(path, b, 0o600)
	}

	out := map[string]any{}
	if existing, err := os.ReadFile(path); err == nil {
		_ = yaml.Unmarshal(existing, &out)
	}
	out["plugin_master_key"] = key
	b, err := yaml.Marshal(&out)
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0o600)
}

func fileExists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}
