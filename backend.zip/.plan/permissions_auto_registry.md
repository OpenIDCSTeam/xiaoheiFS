# 权限自动注册改造计划

## 当前状态分析

| 项目 | 状态 |
|------|------|
| 权限定义 | 手动注册在 `registry.go` 中，约60个权限 |
| 自动注册 | ❌ 不是根据接口自动注册的 |
| 树状展示 | ✅ 已支持（按 category 分类） |
| Friendly Name | ❌ 不支持 |

## 实现方案

### 1. 路由权限注解机制

在 `router.go` 中添加路由权限注解：

```go
// 在路由定义时添加权限注解
admin.GET("/users", handler.AdminUsers).Meta(PermissionMeta{
    Code: "admin.users.list",
    FriendlyName: "查看用户列表",
    Category: "用户管理",
})
```

### 2. 自动注册器

创建 `internal/pkg/permissions/auto_registry.go`：

```go
type RouteMeta struct {
    Path         string
    Method       string
    Permission   string   // 权限码
    FriendlyName string   // 友好名称
    Category     string   // 分类
}

// 从路由树自动提取权限定义
func ScanRoutes(engine *gin.Engine) []RouteMeta
```

### 3. Friendly Name 映射配置

创建配置文件 `config/permission_friendly_names.yaml`：

```yaml
admin.users.list:
  friendly_name: "查看用户列表"
  category: "用户管理"
  sort_order: 1

admin.users.create:
  friendly_name: "创建用户"
  category: "用户管理"
  sort_order: 2
```

### 4. 修改现有路由

将 `RequireAdmin()` 中间件替换为 `RequirePermission(...)`：

```go
// 当前
admin.Use(middleware.RequireAdmin())

// 修改后
admin.GET("/users", middleware.RequirePermission("user.list"), handler.AdminUsers)
admin.POST("/users", middleware.RequirePermission("user.create"), handler.AdminUserCreate)
```

### 5. 修改权限注册流程

在 `main.go` 中：

```go
// 替换现有的手动注册
permissions.InitRegistry()  // 删除

// 改为自动扫描+配置覆盖
autoPerms := permissions.ScanRoutes(server.Engine)
registry := permissions.NewAutoRegistry(autoPerms, config.FriendlyNames)
registry.RegisterToDatabase(ctx, repoSQLite)
```

## 实施步骤

1. 创建 `auto_registry.go` - 路由扫描和自动注册逻辑
2. 创建 `permission_friendly_names.yaml` - Friendly Name 配置文件
3. 添加 `gin.Context` 扩展方法 `Meta()` - 用于路由注解
4. 修改 `router.go` - 添加权限注解到所有管理接口
5. 修改 `main.go` - 使用自动注册替代手动注册
6. 更新 `middleware.go` - 增强权限检查逻辑
7. 更新 `permissions` 包 - 合并自动注册和手动注册
8. 添加配置加载逻辑 - 读取 YAML 配置文件

## 文件变更清单

| 文件 | 操作 | 说明 |
|------|------|------|
| `internal/pkg/permissions/auto_registry.go` | 新建 | 自动注册逻辑 |
| `config/permission_friendly_names.yaml` | 新建 | Friendly Name 配置 |
| `internal/adapter/http/router.go` | 修改 | 添加权限注解 |
| `cmd/server/main.go` | 修改 | 使用自动注册 |
| `internal/pkg/permissions/registry.go` | 修改 | 兼容两种方式 |

## 数据库兼容

权限码格式保持不变（如 `user.list`），现有权限组配置无需迁移。